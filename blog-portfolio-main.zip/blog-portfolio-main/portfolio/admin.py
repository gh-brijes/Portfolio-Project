from django.contrib import admin
from portfolio.models import Expertise, Gallery, About, ContactMessage

admin.site.register(Expertise)
admin.site.register(Gallery)
admin.site.register(About)
admin.site.register(ContactMessage)